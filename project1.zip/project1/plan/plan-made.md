---
marp: true
---

# Project 1 Plan

Submission Deadline (10/18 Sat 23:59 pm)

---

## Your Project 1 Submission Date

1. When (Plan): 10/16 THur  23:59PM
2. When (Actual):10/15 Wed 23:59PM
3. Comment: Will start working on databases the following week after HW 3 is done, set up and test it the following week, and work of tutorial slides in between both sections before Midterm 1 is out.

## Project 1 Milestones

## Milestone 1 Submission

1. What: HW3
2. When (Plan): 9/8 Mon 11:59PM
3. When (Actual): 9/11 Thur 11:59PM
4. Comment: Will be working on HW3 following wee after getting HW 2 done, and will try to have it done by the end of that week so the rest of the weeks and midterm 1 week to focus on Project 1.

## Milestone 2 Submission

1. What: Midterm 1
2. When (Plan): 10/8 Wed 11:59PM
3. When (Actual):10/9 Thur 11:59 PM
4. Comment:Will study the following week before midterm week while working on the project, ad will try to get the midterm done on Wed at the earlist, Thur at the latest. 

## Any milestones if necessary
