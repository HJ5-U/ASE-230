  Week 5 for Student Course Management System-
  Get the studentdb for Mysql set up and set up the table, then make login system for the database, along with MARP slides for each section.

  Week 6 - set up input system and management system for the table and security syetem and make tutoriul slides for them as well.

  Week 7 - make the GUIs of both the table system, run tests on the API, and debug issues, along with making slides for these sections.

  Week 8 - do touch ups on code, and slides, create the folder of project on GitHub, and make a zip file to turn in for grade.

  Week 9-last resort week to work on any issues before turning the project before the due date.